// pages/other/chargeTimePopup/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
      //充电时长列表
    chargingTimeList: [
      {
        id:'1',
        value: 1,
        checked: true
      },{
        id:'2',
        value: 2,
        checked: false
      },{
        id:'3',
        value: 3,
        checked: false
      },{
        id:'4',
        value: 4,
        checked: false
      },{
        id:'5',
        value: 5,
        checked: false
      },{
        id:'6',
        value: 6,
        checked: false
      }
  ],
  //充电桩
  chargerInfo: {
    id: 0,
    label: '一号充电桩',
    hour: 0
  }
   
  },
  onLoad: function(options) {   //重点   
    console.log(111)
    this.chargerInfo.id = options.id
    this.chargerInfo.label = options.label
  },
  /**
   * 组件的方法列表
   */
  methods: {
    checkboxChange: function(e){
      console.log('radio发生change事件，携带value值为：', e.detail.value)

      const items = this.data.chargingTimeList
      for (let i = 0, len = items.length; i < len; ++i) {
        items[i].checked = items[i].value == e.detail.value
        if(items[i].checked){
        console.log(items[i].checked)
         this.data.chargerInfo.hour =  e.detail.value;
         this.setData({ chargerInfo: this.data.chargerInfo});
        }
        console.log(items[i].checked)
      }
      this.setData({
        items
      })
    },
    toPay: function(){
      wx.showToast({
        title: '待开发',
        icon: 'success',
        duration: 2000
       })
    }
  }

})
