// pages/other/chargeRecord/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    //充电记录集合
    chargeRecordList: [{
        id: '1',
        position: '大路田坝充电桩 一号桩',
        createTime: '2020-10-12 11:30:30',
        chargeTime: 2,
        cost: 5.88
     },{
      id: '2',
      position: '大路田坝充电桩 二号桩',
      createTime: '2020-10-11 9:30:30',
      chargeTime: 4,
      cost: 11.84
    },{
      id: '3',
      position: '大路田坝充电桩 一号桩',
      createTime: '2020-10-10 10:30:30',
      chargeTime: 3,
      cost: 8.88
    },{
      id: '4',
      position: '大路田坝充电桩 一号桩',
      createTime: '2020-10-9 11:30:30',
      chargeTime: 2,
      cost: 5.88
    },{
      id: '5',
      position: '大路田坝充电桩 一号桩',
      createTime: '2020-10-8 11:30:30',
      chargeTime: 2,
      cost: 5.88
    }]
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
