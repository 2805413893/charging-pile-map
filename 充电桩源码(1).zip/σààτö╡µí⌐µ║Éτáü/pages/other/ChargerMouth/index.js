// pages/other/ChargerMouth/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    //充电口集合
    chargerMouthList: [{
      id: '1',
      label: '一号充电口',
      isFree: true
  },{
      id: '2',
      label: '二号充电口',
      isFree: false
  },{
      id: '3',
      label: '三号充电口',
      isFree: true
  },{
      id: '4',
      label: '四号充电口',
      isFree: true
  }]

  },

  /**
   * 组件的方法列表
   */
  methods: {
    toChargeTime: function(e){
      const index =  e.currentTarget.dataset.index;
      console.log(index)
      const isFree =  this.data.chargerMouthList[index].isFree;
      if(isFree){
        const label =  this.data.chargerMouthList[index].label;
        const id =  this.data.chargerMouthList[index].id;
        wx.navigateTo({
            url: '../../other/chargeTimePopup/index?id=' + id+'&label='+label
        })
      }else{
        wx.showModal({
            title: '提示',
            content: '请选择空闲的充电口',
            success (res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
      }
        
    },
  }
})
