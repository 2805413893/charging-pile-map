// pages/howFind/index.js
var network = require('../../../utils/network.js');
var util = require('../../../utils/util.js');
var requestUrl = require('../../../config.js');

var app = getApp();
Page({
  data: {
    returnPageUrl: "/pages/tabBar/todayOilPrice/todayOilPrice", //添加或者纠正油价后的返回地址
    currentLongitude: 0, //当前位置的经度
    currentLatitude: 0, //当前位置的纬度
    oilStationMapAdress: "",
    oilStation: {
      oilStationPrice: {}
    },
    //未输入时的描述信息
    oilStationName: '请输入当前充电桩【名称】', //textarea输入框默认的placeholder
    oilStationAdress: '请输入当前充电桩【地址】', //textarea输入框默认的placeholder
    inputToast: '', //头部错误提示存放的信息
    time: '',

    formId: '', // 提交表单生成的id
    canSave: false,
    canClick: false, //保存按钮是否可以点击

    cardCustomMessage: [],
    // 定时器
    time: '',
    beforeEditData: false, //判断之前是否有已经输入的信息
    // 发送模板消息的data
    "data": {
      "keyword1": {},
      "keyword2": {},
      "keyword3": {},
      "keyword4": {},
      "keyword5": {}
    }
  },
  onReady: function() {

  },
  onLoad: function(options) {
  
  },
  onShow: function() {
    
    },
  
  //充电桩名称-输入框
  oilStationNameInput: function(e) { //获取充电桩名称
    this.setData({
      oilStationName: "请输入当前充电桩【名称】"
    });
    var that = this;
    if (e.detail.value != "" && e.detail.value != null) {
      that.data.oilStation.oilStationName = e.detail.value;
      that.setData({
        oilStation: that.data.oilStation
      });
    } else {
      that.showToast("请输入当前充电桩【名称】");
      delete that.data.oilStation.oilStationName;
    }
  },
  
  //充电桩地址-输入框
  oilStationAdressInput: function() { //获得焦点是触发
    console.log("充电桩地址 获得焦点  正在选择地址");
    
  },

  // 点击保存的时候
  formSubmit: function(e) {
  }
    

})