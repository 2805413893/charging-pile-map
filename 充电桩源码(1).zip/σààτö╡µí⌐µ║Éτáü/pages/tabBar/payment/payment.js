//获取应用实例
var network = require('../../../utils/network.js');
var util = require('../../../utils/util.js');
var requestUrl = require('../../../config.js');
const app = getApp();
Page({
    //【付款】页面中的基本数据
    data: {
        chargingPileList: [{
            id: '1',
            label: '一号桩',
            isFree: true
        },{
            id: '2',
            label: '二号桩',
            isFree: false
        },{
            id: '3',
            label: '三号桩',
            isFree: true
        },{
            id: '4',
            label: '四号桩',
            isFree: true
        }]
    },
    onLoad: function (options) {
       /// this.getOilStationByLonLat();
    },
    onShow: function () {

    },
    toChargeMouth: function(e){
      const index =  e.currentTarget.dataset.index;
      console.log(index)
      const isFree =  this.data.chargingPileList[index].isFree;
      if(isFree){
        const label =  this.data.chargingPileList[index].label;
        const id =  this.data.chargingPileList[index].id;
        wx.navigateTo({
            url: '../../other/ChargerMouth/index?id=' + id+'&label='+label
        })
      }else{
        wx.showModal({
            title: '提示',
            content: '请选择空闲的充电桩',
            success (res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
      }
        
    },
    chargingTimeListTip: function(){

    },
    onPullDownRefresh: function () {    //下拉刷新,获取最新的付款码
        //this.getOilStationByLonLat();
    },
    scrollAction: function (e) {
    },
    onPageScroll: function (e) {
    },
    onHide: function () {
    }
})
