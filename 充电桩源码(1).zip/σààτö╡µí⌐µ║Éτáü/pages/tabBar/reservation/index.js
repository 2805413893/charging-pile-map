// pages/tabBar/reservation/index.js
var util = require('../../../utils/util.js');
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
     reservationnumber: '',
     id: '10001',
     label: '哈达充电区',
     show: false,
     timeOut: 30,
     position: '',
     chargePileList: [{
      id: '100011',
      label: '一号充电桩',
      isFree: true,
    },
    {
      id: '100012',
      label: '二号充电桩',
      isFree: true,
    },
    {
      id: '100013',
      label: '三号充电桩',
      isFree: true,
    },
    {
      id: '100014',
      label: '四号充电桩',
      isFree: true,
    }]
  

  },

  /**
   * 组件的方法列表
   */
  methods: {
    reservation:function (e){
      
      var page = this;
     var index = e.currentTarget.dataset.index;
     var checkedChagePile = this.data.chargePileList[index].label
     var  reservationnumber = this.data.reservationnumber;
     var  show = this.data.show;
     var position = this.data.label;
     wx.showModal({
      title: '提示',
      content:'确认预约'+checkedChagePile,
      success (res) {
        if (res.confirm) {
         var n =  util.random(6);
         var text = '成功预约'+position+checkedChagePile+',预约号码：'+n
         page.setData({
          show:true,
          reservationnumber: text
        })
         // 定时函数
        var interval =  setInterval(function(){
           var time =   page.data.timeOut;
            if(time>0){
               time--;
              console.log(time)
            }else {
              time = 30;
              clearInterval(interval)
            }
            page.setData({
              timeOut:time,
            })
          },1000)
         
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
    }
  }
})
