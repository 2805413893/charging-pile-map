/**
 * 地图
 */
var network = require('../../../utils/network.js')
const requestUrl = require('../../../config')
const util = require('../../../utils/util.js')
import NumberAnimate from '../../../utils/NumberAnimate.js'

var app = getApp();
Page({
  data: {
    redActivityFlag: false,
    chargingPileName: "大路田坝充电桩",
    chargingPilePriceList: [{
        period: '11:00~13:00 16:00~17:00',
        label: '尖峰时段',
        price: '1.0941'
      },
      {
        period: '10:00~15:00 18:00~21:00',
        label: '高峰时段',
        price: '1.0044'
      },
      {
        period: '7:00~10:00 15:00~18:00 21:00~23:00',
        label: '平时段',
        price: '0.695'
      },{
        period: '22:30~次日07：00',
        label: '低谷时段',
        price: '0.3946'
      }
    ]
  },
  onLoad: function(options) {

  },
  onShow: function(res) {
    this.getOilStation();
  },
  onHide: function() {

  },
  onReady: function() {

  },
  //在地图中寻找充电桩
  findChargingPileInMap: function() {
    console.log("开始准备跳转地图...");
    wx.navigateTo({
      url: "../../other/chargePileMap/index"
    });
  },
  //下拉刷新获取最新数据
  onPullDownRefresh: function() {
    console.log("开始下拉刷新");
    this.getOilStation(true);
  },
  //纠正电价
  updateOilStation: function() {
    console.log("开始纠正电价");
    wx.navigateTo({
      url: "../../other/chargePileAdd/index?isShowCurrentOilStationFlag=true&title=纠正电价"
    }); 
  },
  officialAccountLoadFuc: function (e) {
    console.log("加载公众号组件");
    console.log(e);
  }

})